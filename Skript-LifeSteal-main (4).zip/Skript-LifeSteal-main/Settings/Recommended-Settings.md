# Recommended Settings

- - -

* CombatTimer = 5-10
* Ghosts = Enabled
* Resurrection = Enabled
* GhostMode = FlightInvisiblity
* Lifesteal = Enabled
* Lifesteal.Hearts = 1-2
* MaxHearts = Enabled
* Lifesteal.MaxHearts = 20
