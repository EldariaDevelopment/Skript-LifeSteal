# Stock Settings
- - -
* CombatTimer = 5
* Ghosts = Enabled
* Resurrection = Disabled
* GhostMode = FlightInvisiblity
* Lifesteal = Disabled
* Lifesteal.Hearts = 1
* MaxHearts = Disabled
* Lifesteal.MaxHearts = 10
