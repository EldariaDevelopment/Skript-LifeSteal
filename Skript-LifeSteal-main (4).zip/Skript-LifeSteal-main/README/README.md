# Skript-LifeSteal
This Software uses a Minecraft plugin called Skript found here: [ https://github.com/SkriptLang/Skript ].
It's advised to only use recommended feature toggles if you just want the Plugin. Most features are customizable but may need icons to be set /setitem
If you need help setting up said plugin contact: Almondz#9877, on discord for help.

## Documentation
* Original Skript Documentation: https://en.njol.ch/projects/skript
* SkriptHub Skript Documentation: https://skripthub.net/docs/
* SkUnity Skript Documentation: https://docs.skunity.com/
### Forums
* SkUnity Skript Forums: https://forums.skunity.com/
#### What You Should do First
>1. Set Items to {HeartIncrease}, {HeartDecrease}, {Heart}, CombatTimerIncrease}, and {CombatTimerDecrease}. 
>2. Use /setitem with the item in your hand.
>3. With the a single heart item in your hand do /setitemstack and allow it time to set the multi-variable.
>4. Edit the /Lifesteal configuration to your liking.
>5. If your just starting use the recommended settting
>6. Use /TestingGui for more commands and testing features.

