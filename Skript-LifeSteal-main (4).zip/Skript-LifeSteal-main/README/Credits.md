# Developers
- - -
| Developers | User | Discord |
| :----: | :----: | :----: |
| Aubrey | Cleveland_OH | Unknown |
| Almond | AlmondDrop11 | Almondz#0001 |
